﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class GameManager : MonoBehaviour
{
    public static GameManager instance = null;
    public int score;
    public int level = 1;
    public Text GemText;

    public void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else if (instance != this)
        {
            Destroy(gameObject);
        }
    }

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    public void AddScore(int gemCount)
    {
        score += gemCount;
    }

    public void GoToLose()
    {
        SceneManager.LoadScene("Lose");
    }
    public void GoToWin()
    {
        SceneManager.LoadScene("Win");
    }

    public void GoToNextLevel()
    {
        SceneManager.LoadScene("GamePlay-Level2");
    }
}

